import React, { useRef, useEffect, useState } from 'react';
import { Maximize, Scissors, Coins, Box, ArrowUp, ArrowRight } from 'lucide-react';
import { PanelState } from '../hooks/usePanelCalculator';

interface PanelVisualizerProps {
  state: PanelState;
  calculations: {
    horizontalWidths: number[];
    verticalHeights: number[];
    hasError: boolean;
    mainCutList: { length: number; count: number }[];
    innerCutList: { length: number; count: number }[];
    totalLinearMeters: number;
    totalWithWaste: number;
    totalCost: number;
  };
}

export function PanelVisualizer({ state, calculations }: PanelVisualizerProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  const [scale, setScale] = useState(1);
  const [selectedPanel, setSelectedPanel] = useState<{ i: number, j: number, width: number, height: number } | null>(null);
  const [is3D, setIs3D] = useState(true);

  const { wallWidth, wallHeight, gap, margin, doubleFrame, innerGap, moldingWidth, wallColor, panelColor, pricePerMeter } = state;
  const { horizontalWidths, verticalHeights, hasError } = calculations;

  useEffect(() => {
    const updateScale = () => {
      if (containerRef.current) {
        const containerWidth = containerRef.current.clientWidth;
        const containerHeight = containerRef.current.clientHeight;
        const availableWidth = containerWidth - 80; 
        const availableHeight = containerHeight - 80;
        
        const scaleX = wallWidth > 0 ? availableWidth / wallWidth : 0;
        const scaleY = wallHeight > 0 ? availableHeight / wallHeight : 0;
        let newScale = Math.min(scaleX, scaleY);
        
        if (!isFinite(newScale) || newScale <= 0) {
          newScale = 1;
        }
        
        setScale(newScale);
      }
    };

    updateScale();
    window.addEventListener('resize', updateScale);
    return () => window.removeEventListener('resize', updateScale);
  }, [wallWidth, wallHeight, hasError]);

  if (hasError) {
    return (
      <div className="w-full h-64 bg-slate-50 rounded-2xl flex items-center justify-center text-slate-400 font-medium border border-slate-100">
        الأبعاد المدخلة غير منطقية
      </div>
    );
  }

  const svgWidth = wallWidth * scale;
  const svgHeight = wallHeight * scale;

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div className="flex gap-4">
          <div className="flex items-center gap-2 text-xs font-bold text-slate-400">
            <ArrowRight className="w-3 h-3" />
            <span>اتجاه X</span>
          </div>
          <div className="flex items-center gap-2 text-xs font-bold text-slate-400">
            <ArrowUp className="w-3 h-3" />
            <span>اتجاه Y</span>
          </div>
        </div>
        <button 
          onClick={() => setIs3D(!is3D)}
          className={`px-4 py-2 rounded-xl text-xs font-bold transition-all ${is3D ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-200' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'}`}
        >
          {is3D ? 'عرض 2D' : 'عرض 3D'}
        </button>
      </div>

      <div 
        ref={containerRef} 
        className="w-full bg-slate-50 rounded-3xl p-8 flex items-center justify-center overflow-hidden relative border border-slate-100 shadow-inner"
        style={{ minHeight: '400px' }}
      >
        <svg 
          width={svgWidth + 40} 
          height={svgHeight + 40} 
          viewBox={`${-20 / scale} ${-20 / scale} ${wallWidth + 40 / scale} ${wallHeight + 40 / scale}`}
          className="overflow-visible transition-all duration-500"
          style={{
            transform: is3D ? 'perspective(1000px) rotateX(10deg) rotateY(-10deg)' : 'none',
            filter: is3D ? 'drop-shadow(20px 20px 30px rgba(0,0,0,0.1))' : 'none'
          }}
        >
          <defs>
            <filter id="panel-shadow" x="-20%" y="-20%" width="140%" height="140%">
              <feDropShadow dx={2 / scale} dy={4 / scale} stdDeviation={3 / scale} floodOpacity="0.1" />
            </filter>
            <marker id="arrowhead" markerWidth="10" markerHeight="7" refX="10" refY="3.5" orient="auto">
              <polygon points="0 0, 10 3.5, 0 7" fill="#94a3b8" />
            </marker>
          </defs>

          {/* Wall */}
          <rect 
            x={0} y={0} width={wallWidth} height={wallHeight} 
            fill={wallColor} 
            rx={4 / scale} 
            stroke="#e2e8f0" 
            strokeWidth={1 / scale} 
          />

          {/* Axis Arrows */}
          <g className="pointer-events-none">
            {/* X Axis */}
            <line x1={0} y1={wallHeight + 30/scale} x2={wallWidth} y2={wallHeight + 30/scale} stroke="#94a3b8" strokeWidth={2/scale} markerEnd="url(#arrowhead)" />
            <text x={wallWidth / 2} y={wallHeight + 45/scale} fontSize={10/scale} fill="#64748b" fontWeight="bold" textAnchor="middle">محور X (العرض)</text>
            
            {/* Y Axis */}
            <line x1={-30/scale} y1={wallHeight} x2={-30/scale} y2={0} stroke="#94a3b8" strokeWidth={2/scale} markerEnd="url(#arrowhead)" />
            <text x={-45/scale} y={wallHeight / 2} fontSize={10/scale} fill="#64748b" fontWeight="bold" textAnchor="middle" transform={`rotate(-90, ${-45/scale}, ${wallHeight / 2})`}>محور Y (الارتفاع)</text>
          </g>

          {/* Panels */}
          {horizontalWidths.map((width, i) => {
            const prevWidths = horizontalWidths.slice(0, i).reduce((a, b) => a + b, 0);
            const x = margin + prevWidths + (i * gap);

            return verticalHeights.map((height, j) => {
              const prevHeights = verticalHeights.slice(0, j).reduce((a, b) => a + b, 0);
              const y = margin + prevHeights + (j * gap);
              const isSelected = selectedPanel?.i === i && selectedPanel?.j === j;
              
              return (
                <g 
                  key={`${i}-${j}`} 
                  className="cursor-pointer group"
                  onClick={() => setSelectedPanel({ i, j, width, height })}
                >
                  {/* Outer Frame */}
                  <rect
                    x={x}
                    y={y}
                    width={width}
                    height={height}
                    fill={panelColor}
                    stroke={isSelected ? "#6366f1" : "#cbd5e1"}
                    strokeWidth={moldingWidth / scale}
                    rx={2 / scale}
                    style={{
                      filter: is3D ? 'url(#panel-shadow)' : 'none',
                      transform: is3D ? 'translateZ(10px)' : 'none'
                    }}
                  />
                  
                  {/* Double Frame */}
                  {doubleFrame && width > (innerGap * 2) && height > (innerGap * 2) && (
                    <rect
                      x={x + innerGap}
                      y={y + innerGap}
                      width={width - (innerGap * 2)}
                      height={height - (innerGap * 2)}
                      fill="none"
                      stroke={isSelected ? "#818cf8" : "#e2e8f0"}
                      strokeWidth={(moldingWidth * 0.7) / scale}
                      rx={1 / scale}
                      style={{ transform: is3D ? 'translateZ(15px)' : 'none' }}
                    />
                  )}

                  {/* Dimensions Text */}
                  <text
                    x={x + width / 2}
                    y={y + height / 2}
                    fontSize={Math.max(8, 12 / scale)}
                    textAnchor="middle"
                    fill="#475569"
                    fontWeight="bold"
                    className="pointer-events-none select-none"
                    style={{ transform: is3D ? 'translateZ(20px)' : 'none' }}
                  >
                    {width.toFixed(1)} × {height.toFixed(1)}
                  </text>
                </g>
              );
            });
          })}
        </svg>
      </div>

      {/* Selected Panel Info */}
      {selectedPanel && (
        <div className="bg-white border border-slate-200 rounded-2xl p-6 shadow-sm animate-in fade-in slide-in-from-bottom-2 duration-300">
          <div className="flex justify-between items-center mb-4">
            <h3 className="font-bold text-slate-800 flex items-center gap-2">
              <Box className="w-4 h-4 text-indigo-600" />
              تفاصيل البانو {selectedPanel.i + 1}
            </h3>
            <button onClick={() => setSelectedPanel(null)} className="text-slate-400 hover:text-slate-600">
              <Maximize className="w-4 h-4 rotate-45" />
            </button>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-3 gap-6">
            <div>
              <p className="text-[10px] text-slate-400 font-bold uppercase mb-1">المقاس الأساسي</p>
              <p className="text-lg font-bold text-slate-700">{selectedPanel.width.toFixed(1)} × {selectedPanel.height.toFixed(1)} سم</p>
            </div>
            {doubleFrame && (
              <div>
                <p className="text-[10px] text-indigo-400 font-bold uppercase mb-1">المقاس الداخلي</p>
                <p className="text-lg font-bold text-indigo-600">{(selectedPanel.width - innerGap * 2).toFixed(1)} × {(selectedPanel.height - innerGap * 2).toFixed(1)} سم</p>
              </div>
            )}
            <div>
              <p className="text-[10px] text-slate-400 font-bold uppercase mb-1">إجمالي الأمتار</p>
              <p className="text-lg font-bold text-slate-700">
                {((selectedPanel.width * 2 + selectedPanel.height * 2 + (doubleFrame ? ((selectedPanel.width - innerGap * 2) * 2 + (selectedPanel.height - innerGap * 2) * 2) : 0)) / 100).toFixed(2)} م
              </p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
