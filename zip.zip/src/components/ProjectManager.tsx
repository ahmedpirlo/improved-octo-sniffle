import React, { useState } from 'react';
import { Folder, Plus, Trash2, Edit2, Check, X } from 'lucide-react';
import { Project } from '../hooks/usePanelCalculator';
import { cn } from '../lib/utils';

interface ProjectManagerProps {
  projects: Project[];
  activeProjectId: string;
  onSelect: (id: string) => void;
  onCreate: (name: string) => void;
  onDelete: (id: string) => void;
  onRename: (id: string, name: string) => void;
}

export function ProjectManager({ projects, activeProjectId, onSelect, onCreate, onDelete, onRename }: ProjectManagerProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [isCreating, setIsCreating] = useState(false);
  const [newProjectName, setNewProjectName] = useState('');
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editName, setEditName] = useState('');

  const activeProject = projects.find(p => p.id === activeProjectId);

  const handleCreate = () => {
    if (newProjectName.trim()) {
      onCreate(newProjectName.trim());
      setNewProjectName('');
      setIsCreating(false);
      setIsOpen(false);
    }
  };

  const handleRename = (id: string) => {
    if (editName.trim()) {
      onRename(id, editName.trim());
      setEditingId(null);
    }
  };

  return (
    <div className="relative">
      <button 
        onClick={() => setIsOpen(!isOpen)}
        className="flex items-center gap-2 bg-white border border-slate-200 px-3 py-2 rounded-xl text-sm font-semibold text-slate-700 hover:bg-slate-50 transition-all"
      >
        <Folder className="w-4 h-4 text-indigo-600" />
        <span className="hidden sm:inline max-w-[120px] truncate">{activeProject?.name}</span>
      </button>

      {isOpen && (
        <>
          <div className="fixed inset-0 z-20" onClick={() => setIsOpen(false)}></div>
          <div className="absolute top-full left-0 sm:right-0 sm:left-auto mt-2 w-72 bg-white rounded-2xl border border-slate-200 shadow-xl z-30 overflow-hidden">
            <div className="p-3 border-b border-slate-100 flex justify-between items-center bg-slate-50">
              <h3 className="font-bold text-slate-800 text-sm">المشاريع المحفوظة</h3>
              <button 
                onClick={() => setIsCreating(true)}
                className="text-indigo-600 hover:text-indigo-700 bg-indigo-100 hover:bg-indigo-200 p-1 rounded-md transition-colors"
                title="مشروع جديد"
              >
                <Plus className="w-4 h-4" />
              </button>
            </div>

            <div className="max-h-64 overflow-y-auto p-2 space-y-1">
              {isCreating && (
                <div className="flex items-center gap-2 p-2 bg-slate-50 rounded-lg border border-indigo-200">
                  <input 
                    autoFocus
                    type="text" 
                    value={newProjectName}
                    onChange={(e) => setNewProjectName(e.target.value)}
                    placeholder="اسم المشروع..."
                    className="flex-1 bg-white border border-slate-200 rounded px-2 py-1 text-sm focus:outline-none focus:border-indigo-500"
                    onKeyDown={(e) => e.key === 'Enter' && handleCreate()}
                  />
                  <button onClick={handleCreate} className="text-indigo-600"><Check className="w-4 h-4" /></button>
                  <button onClick={() => setIsCreating(false)} className="text-slate-400"><X className="w-4 h-4" /></button>
                </div>
              )}

              {projects.map(project => (
                <div 
                  key={project.id}
                  className={cn(
                    "flex items-center justify-between p-2 rounded-lg group transition-colors",
                    project.id === activeProjectId ? "bg-indigo-50 text-indigo-900" : "hover:bg-slate-50 text-slate-700"
                  )}
                >
                  {editingId === project.id ? (
                    <div className="flex items-center gap-2 flex-1">
                      <input 
                        autoFocus
                        type="text" 
                        value={editName}
                        onChange={(e) => setEditName(e.target.value)}
                        className="flex-1 bg-white border border-slate-200 rounded px-2 py-1 text-sm focus:outline-none focus:border-indigo-500"
                        onKeyDown={(e) => e.key === 'Enter' && handleRename(project.id)}
                      />
                      <button onClick={() => handleRename(project.id)} className="text-indigo-600"><Check className="w-4 h-4" /></button>
                      <button onClick={() => setEditingId(null)} className="text-slate-400"><X className="w-4 h-4" /></button>
                    </div>
                  ) : (
                    <>
                      <button 
                        className="flex-1 text-right text-sm font-medium truncate"
                        onClick={() => {
                          onSelect(project.id);
                          setIsOpen(false);
                        }}
                      >
                        {project.name}
                      </button>
                      <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                        <button 
                          onClick={() => {
                            setEditName(project.name);
                            setEditingId(project.id);
                          }}
                          className="p-1 text-slate-400 hover:text-blue-600 transition-colors"
                        >
                          <Edit2 className="w-3.5 h-3.5" />
                        </button>
                        <button 
                          onClick={() => onDelete(project.id)}
                          className="p-1 text-slate-400 hover:text-red-600 transition-colors"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </>
                  )}
                </div>
              ))}
            </div>
          </div>
        </>
      )}
    </div>
  );
}
