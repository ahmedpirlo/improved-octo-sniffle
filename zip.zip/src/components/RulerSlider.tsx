import React from 'react';
import { cn } from '@/src/lib/utils';

interface RulerSliderProps {
  value: number;
  onChange: (val: number) => void;
  min: number;
  max: number;
  label: string;
  unit?: string;
  icon?: React.ReactNode;
  className?: string;
}

export function RulerSlider({ value, onChange, min, max, label, unit, icon, className }: RulerSliderProps) {
  return (
    <div className={cn("flex flex-col gap-2", className)}>
      <div className="flex justify-between items-center">
        <label className="text-sm font-semibold text-slate-700 flex items-center gap-2">
          {icon && <span className="text-slate-400">{icon}</span>}
          {label}
        </label>
        <div className="flex items-center gap-1">
          <input 
            type="number" 
            value={value}
            onChange={(e) => onChange(Number(e.target.value))}
            className="w-16 text-left bg-slate-50 border border-slate-200 rounded-md px-2 py-1 text-sm font-bold text-slate-900 focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500"
          />
          <span className="text-sm font-bold text-slate-500">{unit}</span>
        </div>
      </div>
      
      <div className="relative pt-2 pb-4">
        <input 
          type="range" 
          min={min} 
          max={max} 
          value={value} 
          onChange={(e) => onChange(Number(e.target.value))}
          className="w-full h-2 bg-slate-200 rounded-lg appearance-none cursor-pointer accent-indigo-500 relative z-10"
        />
        {/* Ruler markings */}
        <div className="absolute top-6 left-0 right-0 flex justify-between px-1 pointer-events-none">
          {[...Array(5)].map((_, i) => {
            const markValue = Math.round(min + (max - min) * (i / 4));
            return (
              <div key={i} className="flex flex-col items-center">
                <div className="w-0.5 h-1.5 bg-slate-300 mb-0.5"></div>
                <span className="text-[9px] text-slate-400 font-medium">{markValue}</span>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
