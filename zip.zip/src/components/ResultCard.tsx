import React from 'react';
import { cn } from '@/src/lib/utils';

interface ResultCardProps {
  key?: any;
  title: string;
  width: number;
  height: number;
  count?: number;
  highlight?: boolean;
  className?: string;
}

export function ResultCard({ title, width, height, count, highlight, className }: ResultCardProps) {
  const safeWidth = width || 0;
  const safeHeight = height || 0;

  return (
    <div className={cn(
      "p-4 rounded-2xl border transition-all",
      highlight 
        ? "bg-indigo-50 border-indigo-200 shadow-sm" 
        : "bg-white border-slate-100",
      className
    )}>
      <div className="flex justify-between items-start mb-3">
        <h3 className={cn(
          "font-semibold text-sm",
          highlight ? "text-indigo-800" : "text-slate-600"
        )}>
          {title}
        </h3>
        {count !== undefined && count > 1 && (
          <span className="bg-slate-100 text-slate-600 text-xs font-bold px-2 py-1 rounded-md">
            × {count}
          </span>
        )}
      </div>
      
      <div className="flex items-baseline gap-1">
        <span className="text-2xl font-bold text-slate-900">
          {safeWidth.toFixed(1)}
        </span>
        <span className="text-slate-400 text-sm mx-1">×</span>
        <span className="text-2xl font-bold text-slate-900">
          {safeHeight.toFixed(1)}
        </span>
        <span className="text-slate-500 text-sm ms-1">سم</span>
      </div>
    </div>
  );
}
