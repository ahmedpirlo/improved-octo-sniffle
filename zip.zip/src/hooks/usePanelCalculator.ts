import { useState, useEffect, useMemo, useCallback } from 'react';

export interface PanelState {
  wallWidth: number;
  wallHeight: number;
  panelCount: number;
  verticalPanelCount: number;
  gap: number;
  margin: number;
  swapVertical: boolean;
  pricePerMeter: number;
  doubleFrame: boolean;
  innerGap: number;
  moldingWidth: number;
  wallColor: string;
  panelColor: string;
  standardStickLength: number;
}

export interface Project {
  id: string;
  name: string;
  state: PanelState;
  updatedAt: number;
}

const DEFAULT_STATE: PanelState = {
  wallWidth: 400,
  wallHeight: 280,
  panelCount: 3,
  verticalPanelCount: 2,
  gap: 10,
  margin: 15,
  swapVertical: false,
  pricePerMeter: 50,
  doubleFrame: false,
  innerGap: 10,
  moldingWidth: 4,
  wallColor: '#f1f5f9',
  panelColor: '#ffffff',
  standardStickLength: 240,
};

export function usePanelCalculator() {
  const [projects, setProjects] = useState<Project[]>(() => {
    const saved = localStorage.getItem('panel-calculator-projects');
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        // Ensure new properties exist for older saves
        return parsed.map((p: any) => ({
          ...p,
          state: { ...DEFAULT_STATE, ...p.state }
        }));
      } catch (e) {
        console.error('Failed to parse saved projects', e);
      }
    }
    // Fallback to old state format if exists, otherwise default
    const oldSaved = localStorage.getItem('panel-calculator-state');
    let initialState = DEFAULT_STATE;
    if (oldSaved) {
      try {
        initialState = { ...DEFAULT_STATE, ...JSON.parse(oldSaved) };
      } catch (e) {}
    }
    return [{ id: 'default', name: 'المشروع الافتراضي', state: initialState, updatedAt: Date.now() }];
  });

  const [activeProjectId, setActiveProjectId] = useState<string>(() => {
    const saved = localStorage.getItem('panel-calculator-active-project');
    return saved || 'default';
  });

  const [history, setHistory] = useState<PanelState[]>([]);
  const [historyIndex, setHistoryIndex] = useState<number>(-1);

  const activeProject = useMemo(() => {
    return projects.find(p => p.id === activeProjectId) || projects[0];
  }, [projects, activeProjectId]);

  const state = activeProject.state;

  useEffect(() => {
    setHistory([activeProject.state]);
    setHistoryIndex(0);
  }, [activeProjectId]);

  useEffect(() => {
    localStorage.setItem('panel-calculator-projects', JSON.stringify(projects));
    localStorage.setItem('panel-calculator-active-project', activeProjectId);
  }, [projects, activeProjectId]);

  const updateState = useCallback((updates: Partial<PanelState>, saveHistory: boolean = true) => {
    const newState = { ...state, ...updates };
    
    if (saveHistory) {
      setHistory(prev => {
        const newHistory = prev.slice(0, historyIndex + 1);
        newHistory.push(newState);
        return newHistory;
      });
      setHistoryIndex(prev => prev + 1);
    }

    setProjects(prev => prev.map(p => 
      p.id === activeProjectId 
        ? { ...p, state: newState, updatedAt: Date.now() } 
        : p
    ));
  }, [state, historyIndex, activeProjectId]);

  const undo = useCallback(() => {
    if (historyIndex > 0) {
      const newIndex = historyIndex - 1;
      setHistoryIndex(newIndex);
      const previousState = history[newIndex];
      setProjects(prev => prev.map(p => 
        p.id === activeProjectId 
          ? { ...p, state: previousState, updatedAt: Date.now() } 
          : p
      ));
    }
  }, [history, historyIndex, activeProjectId]);

  const redo = useCallback(() => {
    if (historyIndex < history.length - 1) {
      const newIndex = historyIndex + 1;
      setHistoryIndex(newIndex);
      const nextState = history[newIndex];
      setProjects(prev => prev.map(p => 
        p.id === activeProjectId 
          ? { ...p, state: nextState, updatedAt: Date.now() } 
          : p
      ));
    }
  }, [history, historyIndex, activeProjectId]);

  const createProject = (name: string) => {
    const newProject: Project = {
      id: Date.now().toString(),
      name,
      state: DEFAULT_STATE,
      updatedAt: Date.now(),
    };
    setProjects(prev => [...prev, newProject]);
    setActiveProjectId(newProject.id);
  };

  const deleteProject = (id: string) => {
    const filtered = projects.filter(p => p.id !== id);
    if (filtered.length === 0) {
      const newDefault = { id: 'default', name: 'المشروع الافتراضي', state: DEFAULT_STATE, updatedAt: Date.now() };
      setProjects([newDefault]);
      setActiveProjectId(newDefault.id);
    } else {
      setProjects(filtered);
      if (activeProjectId === id) {
        setActiveProjectId(filtered[0].id);
      }
    }
  };

  const renameProject = (id: string, newName: string) => {
    setProjects(prev => prev.map(p => p.id === id ? { ...p, name: newName, updatedAt: Date.now() } : p));
  };

  const applyTemplate = useCallback((templateId: string) => {
    switch (templateId) {
      case 'classic-3':
        updateState({ panelCount: 3, verticalPanelCount: 1, gap: 15, margin: 20, doubleFrame: false });
        break;
      case 'modern-split':
        updateState({ panelCount: 3, verticalPanelCount: 2, gap: 10, margin: 15, doubleFrame: true, innerGap: 8, swapVertical: false });
        break;
      case 'large-center':
        updateState({ panelCount: 3, verticalPanelCount: 1, gap: 12, margin: 15, doubleFrame: true, innerGap: 10 });
        break;
      case 'vertical-5':
        updateState({ panelCount: 5, verticalPanelCount: 1, gap: 8, margin: 12, doubleFrame: false });
        break;
      case 'grid-4x2':
        updateState({ panelCount: 4, verticalPanelCount: 2, gap: 10, margin: 15, doubleFrame: false });
        break;
    }
  }, [updateState]);

  const calculations = useMemo(() => {
    const { wallWidth, wallHeight, panelCount, verticalPanelCount, gap, margin, swapVertical, pricePerMeter, doubleFrame, innerGap, standardStickLength } = state;
    const GOLDEN_RATIO = 1.618;

    const availableWidth = wallWidth - (2 * margin) - ((panelCount - 1) * gap);
    let horizontalWidths: number[] = [];

    if (availableWidth > 0 && panelCount > 0) {
      if (panelCount % 2 === 0) {
        const width = availableWidth / panelCount;
        horizontalWidths = Array(panelCount).fill(width);
      } else {
        if (panelCount === 1) {
          horizontalWidths = [availableWidth];
        } else if (panelCount === 5) {
          // Double golden ratio for 5 panels: A, B, C, B, A
          // B = A * GOLDEN_RATIO
          // C = B * GOLDEN_RATIO = A * GOLDEN_RATIO^2
          const ratioSum = 2 + (2 * GOLDEN_RATIO) + Math.pow(GOLDEN_RATIO, 2);
          const aWidth = availableWidth / ratioSum;
          const bWidth = aWidth * GOLDEN_RATIO;
          const cWidth = bWidth * GOLDEN_RATIO;
          
          horizontalWidths = [aWidth, bWidth, cWidth, bWidth, aWidth];
        } else {
          const baseWidth = availableWidth / (panelCount - 1 + GOLDEN_RATIO);
          const middleWidth = baseWidth * GOLDEN_RATIO;
          
          horizontalWidths = Array(panelCount).fill(baseWidth);
          const middleIndex = Math.floor(panelCount / 2);
          horizontalWidths[middleIndex] = middleWidth;
        }
      }
    }

    const availableHeight = wallHeight - (2 * margin) - ((verticalPanelCount - 1) * gap);
    let verticalHeights: number[] = [];

    if (availableHeight > 0 && verticalPanelCount > 0) {
      if (verticalPanelCount === 1) {
        verticalHeights = [availableHeight];
      } else if (verticalPanelCount === 2) {
        const baseHeight = availableHeight / (1 + GOLDEN_RATIO);
        const largerHeight = baseHeight * GOLDEN_RATIO;
        verticalHeights = swapVertical ? [baseHeight, largerHeight] : [largerHeight, baseHeight];
      } else if (verticalPanelCount % 2 === 0) {
        const height = availableHeight / verticalPanelCount;
        verticalHeights = Array(verticalPanelCount).fill(height);
      } else {
        const baseHeight = availableHeight / (verticalPanelCount - 1 + GOLDEN_RATIO);
        const middleHeight = baseHeight * GOLDEN_RATIO;
        verticalHeights = Array(verticalPanelCount).fill(baseHeight);
        verticalHeights[Math.floor(verticalPanelCount / 2)] = middleHeight;
      }
    }

    // --- Rounding and Balancing to Whole Numbers ---
    const roundAndBalance = (values: number[], targetSum: number) => {
      const rounded = values.map(v => Math.round(v));
      let currentSum = rounded.reduce((a, b) => a + b, 0);
      let diff = Math.round(targetSum) - currentSum;
      
      if (diff !== 0) {
        const fractionalParts = values.map((v, i) => ({ index: i, frac: v - Math.floor(v) }));
        if (diff > 0) {
          fractionalParts.sort((a, b) => b.frac - a.frac);
          for (let i = 0; i < diff; i++) {
            rounded[fractionalParts[i % values.length].index] += 1;
          }
        } else {
          fractionalParts.sort((a, b) => a.frac - b.frac);
          for (let i = 0; i < Math.abs(diff); i++) {
            rounded[fractionalParts[i % values.length].index] -= 1;
          }
        }
      }
      return rounded;
    };

    if (horizontalWidths.length > 0) {
      horizontalWidths = roundAndBalance(horizontalWidths, availableWidth);
    }
    if (verticalHeights.length > 0) {
      verticalHeights = roundAndBalance(verticalHeights, availableHeight);
    }

    // --- Golden Ratio Analysis (Panel-based) ---
    const avgPanelWidth = horizontalWidths.reduce((a, b) => a + b, 0) / (horizontalWidths.length || 1);
    const avgPanelHeight = verticalHeights.reduce((a, b) => a + b, 0) / (verticalHeights.length || 1);
    const panelRatio = avgPanelHeight / (avgPanelWidth || 1);
    
    // Ideal ratio is 1.618 (vertical) or 0.618 (horizontal)
    const isFarFromGolden = Math.abs(panelRatio - GOLDEN_RATIO) > 0.4 && Math.abs(panelRatio - (1 / GOLDEN_RATIO)) > 0.4;
    
    const goldenSuggestions: { count: number; width: number; ratio: number }[] = [];
    for (let c = 1; c <= 12; c++) {
      const w = (wallWidth - (2 * margin) - ((c - 1) * gap)) / c;
      if (w > 15) { // minimum sensible width
        const r = avgPanelHeight / w;
        const diff = Math.min(Math.abs(r - GOLDEN_RATIO), Math.abs(r - (1 / GOLDEN_RATIO)));
        if (diff < 0.4 && c !== panelCount) {
          goldenSuggestions.push({ count: c, width: Math.round(w), ratio: r });
        }
      }
    }
    goldenSuggestions.sort((a, b) => {
      const diffA = Math.min(Math.abs(a.ratio - GOLDEN_RATIO), Math.abs(a.ratio - (1/GOLDEN_RATIO)));
      const diffB = Math.min(Math.abs(b.ratio - GOLDEN_RATIO), Math.abs(b.ratio - (1/GOLDEN_RATIO)));
      return diffA - diffB;
    });
    const topSuggestions = goldenSuggestions.slice(0, 3);

    // --- Material & Cost Calculations ---
    const mainCutMap = new Map<number, number>();
    const innerCutMap = new Map<number, number>();
    let totalLinearCentimeters = 0;

    // Each panel needs 2 horizontal pieces and 2 vertical pieces.
    if (horizontalWidths.length > 0 && verticalHeights.length > 0) {
      horizontalWidths.forEach((w) => {
        verticalHeights.forEach((h) => {
          // Horizontal pieces for this panel
          const hCount = 2;
          const preciseW = Number(w.toFixed(1));
          mainCutMap.set(preciseW, (mainCutMap.get(preciseW) || 0) + hCount);
          totalLinearCentimeters += w * hCount;

          // Vertical pieces for this panel
          const vCount = 2;
          const preciseH = Number(h.toFixed(1));
          mainCutMap.set(preciseH, (mainCutMap.get(preciseH) || 0) + vCount);
          totalLinearCentimeters += h * vCount;

          if (doubleFrame && w > (innerGap * 2) && h > (innerGap * 2)) {
            const innerW = w - (innerGap * 2);
            const innerH = h - (innerGap * 2);
            
            const preciseInnerW = Number(innerW.toFixed(1));
            innerCutMap.set(preciseInnerW, (innerCutMap.get(preciseInnerW) || 0) + hCount);
            totalLinearCentimeters += innerW * hCount;

            const preciseInnerH = Number(innerH.toFixed(1));
            innerCutMap.set(preciseInnerH, (innerCutMap.get(preciseInnerH) || 0) + vCount);
            totalLinearCentimeters += innerH * vCount;
          }
        });
      });
    }

    const mainCutList = Array.from(mainCutMap.entries())
      .map(([length, count]) => ({ length, count }))
      .sort((a, b) => b.length - a.length);

    const innerCutList = Array.from(innerCutMap.entries())
      .map(([length, count]) => ({ length, count }))
      .sort((a, b) => b.length - a.length);

    const totalLinearMeters = totalLinearCentimeters / 100;
    const totalWithWaste = totalLinearMeters * 1.1; // Add 10% waste factor
    const totalCost = totalWithWaste * (pricePerMeter || 0);

    // --- Cutting Optimization (Splicing / Smart Cutting) ---
    const optimizeSticks = (pieces: number[]) => {
      const safeStickLength = Math.max(1, standardStickLength);
      const sticks: { remaining: number; pieces: { length: number; isPartial?: boolean; originalLength?: number; pieceId?: number }[] }[] = [];
      let currentStick = { remaining: safeStickLength, pieces: [] as { length: number; isPartial?: boolean; originalLength?: number; pieceId?: number }[] };
      const MIN_SPLICING_LENGTH = 30; // Pieces smaller than 30cm are considered waste if they are just remainders

      let pieceIdCounter = 1;

      pieces.forEach(pieceLength => {
        let remainingPiece = pieceLength;
        let isSplit = false;
        const currentPieceId = pieceIdCounter++;

        // If we need to splice, but the remaining part is too small (< 30cm), it's not worth splicing. Discard it.
        if (remainingPiece > currentStick.remaining && currentStick.remaining < MIN_SPLICING_LENGTH && currentStick.pieces.length > 0) {
          sticks.push(currentStick);
          currentStick = { remaining: safeStickLength, pieces: [] };
        }

        // If the piece is larger than what's remaining, it will be split across sticks
        if (remainingPiece > currentStick.remaining) {
          isSplit = true;
        }

        while (remainingPiece > 0) {
          if (currentStick.remaining <= 0) {
            sticks.push(currentStick);
            currentStick = { remaining: safeStickLength, pieces: [] };
          }

          const canFit = Math.min(remainingPiece, currentStick.remaining);
          
          currentStick.pieces.push({
            length: Number(canFit.toFixed(1)),
            isPartial: isSplit,
            originalLength: pieceLength,
            pieceId: currentPieceId
          });
          
          remainingPiece -= canFit;
          currentStick.remaining -= canFit;
        }
      });
      
      if (currentStick.pieces.length > 0) {
        sticks.push(currentStick);
      }
      
      return sticks;
    };

    const mainPieces: number[] = [];
    mainCutList.forEach(c => {
      for (let i = 0; i < c.count; i++) mainPieces.push(c.length);
    });

    const innerPieces: number[] = [];
    innerCutList.forEach(c => {
      for (let i = 0; i < c.count; i++) innerPieces.push(c.length);
    });

    const mainSticks = optimizeSticks(mainPieces);
    const innerSticks = optimizeSticks(innerPieces);

    const totalSticksNeeded = mainSticks.length + innerSticks.length;
    const totalWaste = (mainSticks.reduce((acc, s) => acc + s.remaining, 0) + innerSticks.reduce((acc, s) => acc + s.remaining, 0)) / 100;

    // --- Laser Marking Guide Coordinates (Starting from Bottom-Right) ---
    const panelCoordinates: { x: number; y: number; width: number; height: number; col: number; row: number }[] = [];
    let currentX = margin;
    
    // We start from the rightmost panel
    const reversedWidths = [...horizontalWidths].reverse();
    const reversedHeights = [...verticalHeights].reverse();

    reversedWidths.forEach((w, colIdx) => {
      let currentY = margin; // Starting from bottom
      reversedHeights.forEach((h, rowIdx) => {
        panelCoordinates.push({
          x: Number(currentX.toFixed(1)),
          y: Number(currentY.toFixed(1)),
          width: Number(w.toFixed(1)),
          height: Number(h.toFixed(1)),
          col: colIdx + 1, // Column 1 is the rightmost
          row: rowIdx + 1  // Row 1 is the bottom-most
        });
        currentY += h + gap;
      });
      currentX += w + gap;
    });

    // --- Laser Marking Grid (All X and Y lines) ---
    const gridX: number[] = [];
    const gridY: number[] = [];

    let tempX = margin;
    reversedWidths.forEach((w, idx) => {
      gridX.push(Number(tempX.toFixed(1))); // Start of panel
      tempX += w;
      gridX.push(Number(tempX.toFixed(1))); // End of panel
      if (idx < reversedWidths.length - 1) {
        tempX += gap;
      }
    });

    let tempY = margin;
    reversedHeights.forEach((h, idx) => {
      gridY.push(Number(tempY.toFixed(1))); // Bottom of panel
      tempY += h;
      gridY.push(Number(tempY.toFixed(1))); // Top of panel
      if (idx < reversedHeights.length - 1) {
        tempY += gap;
      }
    });

    const hasError = 
      isNaN(wallWidth) || isNaN(wallHeight) || 
      wallWidth <= 0 || wallHeight <= 0 || 
      panelCount <= 0 || verticalPanelCount <= 0 ||
      standardStickLength <= 0;

    return {
      horizontalWidths,
      verticalHeights,
      panelWidth: avgPanelWidth,
      panelHeight: avgPanelHeight,
      isFarFromGolden,
      topSuggestions,
      hasError,
      mainCutList,
      innerCutList,
      totalLinearMeters,
      totalWithWaste,
      totalCost,
      mainSticks,
      innerSticks,
      totalSticksNeeded,
      totalWaste,
      panelCoordinates,
      gridX,
      gridY,
      panelRatio
    };
  }, [state]);

  return {
    state,
    updateState,
    calculations,
    projects,
    activeProjectId,
    setActiveProjectId,
    createProject,
    deleteProject,
    renameProject,
    applyTemplate,
    undo,
    redo,
    canUndo: historyIndex > 0,
    canRedo: historyIndex < history.length - 1,
  };
}
