import React, { useState } from 'react';
import { 
  Maximize, 
  Scissors, 
  Coins, 
  Box, 
  Sparkles, 
  Calculator, 
  Settings2, 
  Info,
  ArrowRight,
  ArrowUp,
  History,
  RotateCcw,
  RotateCw,
  LayoutGrid,
  Folder
} from 'lucide-react';
import { usePanelCalculator } from './hooks/usePanelCalculator';
import { PanelVisualizer } from './components/PanelVisualizer';
import { ProjectManager } from './components/ProjectManager';
import { InputField } from './components/InputField';
import { ResultCard } from './components/ResultCard';
import { RulerSlider } from './components/RulerSlider';
import { AIAssistant } from './components/AIAssistant';

function App() {
  const { 
    state, 
    updateState, 
    calculations, 
    projects, 
    activeProjectId, 
    setActiveProjectId, 
    createProject, 
    deleteProject, 
    renameProject,
    undo,
    redo,
    canUndo,
    canRedo
  } = usePanelCalculator();

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 font-sans" dir="rtl">
      {/* Header */}
      <header className="bg-white border-b border-slate-200 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 h-16 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-indigo-600 rounded-xl flex items-center justify-center shadow-lg shadow-indigo-100">
              <LayoutGrid className="w-6 h-6 text-white" />
            </div>
            <h1 className="text-xl font-bold tracking-tight text-slate-900">حساب البانوهات</h1>
          </div>
          
          <div className="flex items-center gap-2">
            <div className="flex items-center gap-1 bg-slate-100 p-1 rounded-xl border border-slate-200 mr-2">
              <button 
                onClick={undo} 
                disabled={!canUndo}
                className="p-1.5 rounded-lg text-slate-500 hover:bg-white hover:text-indigo-600 disabled:opacity-30 disabled:hover:bg-transparent transition-all"
              >
                <RotateCcw className="w-4 h-4" />
              </button>
              <button 
                onClick={redo} 
                disabled={!canRedo}
                className="p-1.5 rounded-lg text-slate-500 hover:bg-white hover:text-indigo-600 disabled:opacity-30 disabled:hover:bg-transparent transition-all"
              >
                <RotateCw className="w-4 h-4" />
              </button>
            </div>
            
            <ProjectManager 
              projects={projects}
              activeProjectId={activeProjectId}
              onSelect={setActiveProjectId}
              onCreate={createProject}
              onDelete={deleteProject}
              onRename={renameProject}
            />
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          
          {/* Left Column: Inputs */}
          <div className="lg:col-span-4 space-y-6">
            {/* Wall Dimensions */}
            <section className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm space-y-4">
              <h2 className="font-bold text-slate-800 flex items-center gap-2">
                <Maximize className="w-4 h-4 text-indigo-600" />
                أبعاد الحائط
              </h2>
              <div className="grid grid-cols-2 gap-4">
                <InputField 
                  label="العرض" 
                  unit="سم"
                  value={state.wallWidth}
                  onChange={(e) => updateState({ wallWidth: parseFloat(e.target.value) || 0 })}
                />
                <InputField 
                  label="الارتفاع" 
                  unit="سم"
                  value={state.wallHeight}
                  onChange={(e) => updateState({ wallHeight: parseFloat(e.target.value) || 0 })}
                />
              </div>
            </section>

            {/* Panel Configuration */}
            <section className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm space-y-6">
              <h2 className="font-bold text-slate-800 flex items-center gap-2">
                <Settings2 className="w-4 h-4 text-indigo-600" />
                توزيع البانوهات
              </h2>

              <div className="space-y-4">
                <RulerSlider 
                  label="عدد البانوهات"
                  min={1}
                  max={10}
                  value={state.panelCount}
                  onChange={(val) => updateState({ panelCount: val })}
                />

                <div className="space-y-2">
                  <label className="text-sm font-semibold text-slate-700">عدد الصفوف</label>
                  <div className="flex gap-2">
                    {[1, 2, 3].map(num => (
                      <button
                        key={num}
                        onClick={() => updateState({ verticalPanelCount: num })}
                        className={`flex-1 py-2 rounded-xl font-bold text-xs transition-all ${state.verticalPanelCount === num ? 'bg-indigo-600 text-white shadow-md shadow-indigo-100' : 'bg-slate-100 text-slate-500 hover:bg-slate-200'}`}
                      >
                        {num}
                      </button>
                    ))}
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <InputField 
                    label="المسافة الجانبية" 
                    unit="سم"
                    value={state.margin}
                    onChange={(e) => updateState({ margin: parseFloat(e.target.value) || 0 })}
                  />
                  <InputField 
                    label="المسافة البينية" 
                    unit="سم"
                    value={state.gap}
                    onChange={(e) => updateState({ gap: parseFloat(e.target.value) || 0 })}
                  />
                </div>
              </div>
            </section>

            {/* Advanced Options */}
            <section className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm space-y-4">
              <h2 className="font-bold text-slate-800 flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-indigo-600" />
                خيارات متقدمة
              </h2>

              <div className="space-y-4">
                <label className="flex items-center justify-between p-3 bg-slate-50 rounded-xl border border-slate-100 cursor-pointer hover:bg-slate-100 transition-all">
                  <span className="text-sm font-bold text-slate-700">برواز داخلي (Double Frame)</span>
                  <input 
                    type="checkbox" 
                    checked={state.doubleFrame}
                    onChange={(e) => updateState({ doubleFrame: e.target.checked })}
                    className="w-4 h-4 accent-indigo-600"
                  />
                </label>

                {state.doubleFrame && (
                  <InputField 
                    label="المسافة بين البروازين" 
                    unit="سم"
                    value={state.innerGap}
                    onChange={(e) => updateState({ innerGap: parseFloat(e.target.value) || 0 })}
                    className="bg-indigo-50/50 p-3 rounded-xl border border-indigo-100"
                  />
                )}

                <div className="grid grid-cols-2 gap-4">
                  <InputField 
                    label="عرض العود" 
                    unit="سم"
                    value={state.moldingWidth}
                    onChange={(e) => updateState({ moldingWidth: parseFloat(e.target.value) || 0 })}
                  />
                  <InputField 
                    label="طول العود الخام" 
                    unit="سم"
                    value={state.standardStickLength}
                    onChange={(e) => updateState({ standardStickLength: parseFloat(e.target.value) || 0 })}
                  />
                </div>

                <InputField 
                  label="سعر المتر الطولي" 
                  unit="ج.م"
                  value={state.pricePerMeter}
                  onChange={(e) => updateState({ pricePerMeter: parseFloat(e.target.value) || 0 })}
                  className="bg-emerald-50/50 p-3 rounded-xl border border-emerald-100"
                  icon={<Coins className="w-4 h-4 text-emerald-600" />}
                />
              </div>
            </section>
          </div>

          {/* Right Column: Visualizer & Results */}
          <div className="lg:col-span-8 space-y-8">
            {/* Quick Summary Bar - ALWAYS VISIBLE */}
            {!calculations.hasError && (
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <div className="bg-indigo-600 p-4 rounded-2xl shadow-lg shadow-indigo-100 text-white">
                  <p className="text-[10px] font-bold uppercase opacity-80 mb-1">إجمالي الأمتار</p>
                  <p className="text-2xl font-black">{calculations.totalLinearMeters.toFixed(2)} <span className="text-xs font-normal">م</span></p>
                </div>
                <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-sm">
                  <p className="text-[10px] text-slate-400 font-bold uppercase mb-1">عدد الأعواد</p>
                  <p className="text-2xl font-black text-indigo-600">{calculations.totalSticksNeeded} <span className="text-xs font-normal text-slate-400">عود</span></p>
                </div>
                <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-sm">
                  <p className="text-[10px] text-slate-400 font-bold uppercase mb-1">عدد البانوهات</p>
                  <p className="text-2xl font-black text-slate-800">{state.panelCount * state.verticalPanelCount}</p>
                </div>
                <div className="bg-emerald-600 p-4 rounded-2xl shadow-lg shadow-emerald-100 text-white">
                  <p className="text-[10px] font-bold uppercase opacity-80 mb-1">التكلفة الإجمالية</p>
                  <p className="text-2xl font-black">
                    {state.pricePerMeter > 0 ? `${calculations.totalCost.toLocaleString()} ج.م` : 'حدد السعر'}
                  </p>
                </div>
              </div>
            )}

            {/* Visualizer Card */}
            <div className="bg-white p-6 sm:p-8 rounded-3xl border border-slate-200 shadow-sm">
              <div className="flex items-center justify-between mb-6">
                <h2 className="font-bold text-lg text-slate-800 flex items-center gap-2">
                  <LayoutGrid className="w-5 h-5 text-indigo-600" />
                  معاينة التصميم
                </h2>
                <div className="flex items-center gap-3">
                  <div className="flex items-center gap-2 bg-slate-50 px-3 py-1.5 rounded-xl border border-slate-100">
                    <span className="text-[10px] font-bold text-slate-400 uppercase">لون الحائط</span>
                    <input 
                      type="color" 
                      value={state.wallColor} 
                      onChange={(e) => updateState({ wallColor: e.target.value })} 
                      className="w-5 h-5 rounded cursor-pointer border-none bg-transparent" 
                    />
                  </div>
                </div>
              </div>

              <PanelVisualizer state={state} calculations={calculations} />
              
              {!calculations.hasError && (
                <div className="mt-8 pt-8 border-t border-slate-100">
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                    <div className="space-y-1">
                      <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest">عرض البانو</p>
                      <p className="text-lg font-bold text-slate-700">{calculations.panelWidth.toFixed(1)} سم</p>
                    </div>
                    <div className="space-y-1">
                      <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest">ارتفاع البانو</p>
                      <p className="text-lg font-bold text-slate-700">{calculations.panelHeight.toFixed(1)} سم</p>
                    </div>
                    <div className="space-y-1">
                      <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest">مع الهالك (5%)</p>
                      <p className="text-lg font-bold text-indigo-600">{calculations.totalWithWaste.toFixed(2)} م</p>
                    </div>
                    <div className="space-y-1">
                      <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest">إجمالي الهالك</p>
                      <p className="text-lg font-bold text-slate-700">{calculations.totalWaste.toFixed(1)} م</p>
                    </div>
                  </div>
                </div>
              )}
            </div>

            {/* Results Section */}
            {!calculations.hasError && (
              <div className="space-y-8">
                {/* Laser Marking Guide */}
                {calculations.gridX && calculations.gridX.length > 0 && (
                  <div className="bg-white p-8 rounded-3xl border border-slate-200 shadow-sm space-y-8">
                    <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                      <h2 className="font-bold text-lg text-slate-800 flex items-center gap-2">
                        <Sparkles className="w-5 h-5 text-indigo-600" />
                        شبكة علامات الليزر (Grid Layout)
                      </h2>
                      <div className="bg-indigo-50 px-4 py-1.5 rounded-full border border-indigo-100">
                        <span className="text-[10px] font-bold text-indigo-700">القياس من أسفل يمين الحائط</span>
                      </div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                      <div className="space-y-4">
                        <h3 className="text-xs font-bold text-slate-400 uppercase tracking-widest flex items-center gap-2">
                          <ArrowRight className="w-4 h-4" />
                          خطوط الليزر الرأسية (X)
                        </h3>
                        <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                          {calculations.gridX.map((val, i) => (
                            <div key={i} className="bg-slate-50 p-4 rounded-2xl border border-slate-100 flex flex-col items-center">
                              <span className="text-[10px] text-slate-400 font-bold mb-1">X{i + 1}</span>
                              <span className="text-xl font-bold text-slate-800">{val.toFixed(1)} <span className="text-xs text-slate-400">سم</span></span>
                            </div>
                          ))}
                        </div>
                      </div>

                      <div className="space-y-4">
                        <h3 className="text-xs font-bold text-slate-400 uppercase tracking-widest flex items-center gap-2">
                          <ArrowUp className="w-4 h-4" />
                          خطوط الليزر الأفقية (Y)
                        </h3>
                        <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                          {calculations.gridY.map((val, i) => (
                            <div key={i} className="bg-slate-50 p-4 rounded-2xl border border-slate-100 flex flex-col items-center">
                              <span className="text-[10px] text-slate-400 font-bold mb-1">Y{i + 1}</span>
                              <span className="text-xl font-bold text-slate-800">{val.toFixed(1)} <span className="text-xs text-slate-400">سم</span></span>
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>

                    <div className="p-6 bg-indigo-50 rounded-2xl border border-indigo-100 flex items-start gap-4">
                      <Info className="w-5 h-5 text-indigo-600 mt-0.5" />
                      <p className="text-sm text-indigo-900 leading-relaxed">
                        ابدأ بتوقيع جميع نقاط <span className="font-bold">X</span> من الركن الأيمن للحائط، ثم وقع نقاط <span className="font-bold">Y</span> من الأرض للأعلى. تقاطع هذه الخطوط هو المكان الدقيق لزوايا البانوهات.
                      </p>
                    </div>
                  </div>
                )}

                {/* Cut Lists */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {/* Main Frame Cut List */}
                  {calculations.mainCutList.length > 0 && (
                    <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
                      <h2 className="font-bold text-slate-800 flex items-center gap-2 mb-4">
                        <Scissors className="w-4 h-4 text-indigo-500" />
                        مقاسات البرواز الأساسي
                      </h2>
                      <div className="grid grid-cols-1 gap-3">
                        {calculations.mainCutList.map((cut, index) => (
                          <ResultCard 
                            key={index}
                            title={`قطعة ${index + 1}`}
                            width={cut.length}
                            height={state.moldingWidth}
                            count={cut.count}
                          />
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Inner Frame Cut List */}
                  {state.doubleFrame && calculations.innerCutList && calculations.innerCutList.length > 0 && (
                    <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
                      <h2 className="font-bold text-slate-800 flex items-center gap-2 mb-4">
                        <Box className="w-4 h-4 text-indigo-500" />
                        مقاسات البرواز الداخلي
                      </h2>
                      <div className="grid grid-cols-1 gap-3">
                        {calculations.innerCutList.map((cut, index) => (
                          <ResultCard 
                            key={index}
                            title={`قطعة داخلية ${index + 1}`}
                            width={cut.length}
                            height={state.moldingWidth * 0.7}
                            count={cut.count}
                            highlight
                          />
                        ))}
                      </div>
                    </div>
                  )}
                </div>

                {/* Optimized Cutting Plan */}
                {((calculations.mainSticks && calculations.mainSticks.length > 0) || (calculations.innerSticks && calculations.innerSticks.length > 0)) && (
                  <div className="bg-white p-8 rounded-3xl border border-slate-200 shadow-sm space-y-8">
                    <div className="flex items-center justify-between">
                      <h2 className="font-bold text-lg text-slate-800 flex items-center gap-2">
                        <Calculator className="w-5 h-5 text-indigo-600" />
                        خطة التقطيع الذكية
                      </h2>
                      <div className="flex gap-6">
                        <div className="text-center">
                          <p className="text-[10px] text-slate-400 font-bold uppercase">الأعواد</p>
                          <p className="text-xl font-bold text-indigo-600">{calculations.totalSticksNeeded}</p>
                        </div>
                        <div className="text-center">
                          <p className="text-[10px] text-slate-400 font-bold uppercase">الهالك</p>
                          <p className="text-xl font-bold text-slate-800">{calculations.totalWaste.toFixed(1)} م</p>
                        </div>
                      </div>
                    </div>

                    {/* Main Sticks */}
                    {calculations.mainSticks && calculations.mainSticks.length > 0 && (
                      <div className="space-y-4">
                        <h3 className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">أعواد البرواز الأساسي</h3>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          {calculations.mainSticks.map((stick, idx) => (
                            <div key={idx} className="bg-slate-50 border border-slate-100 rounded-2xl p-4 space-y-4">
                              <div className="flex justify-between items-center">
                                <span className="text-xs font-bold text-slate-500">العود {idx + 1}</span>
                                <span className="text-[10px] font-bold text-indigo-600">المتبقي: {stick.remaining.toFixed(1)} سم</span>
                              </div>
                              <div className="h-8 bg-white rounded-xl flex overflow-hidden border border-slate-200 p-1 gap-0.5">
                                {stick.pieces.map((piece, pIdx) => (
                                  <div 
                                    key={pIdx}
                                    title={piece.isPartial ? `جزء من قطعة رقم ${piece.pieceId} (إجمالي ${piece.originalLength} سم)` : `قطعة رقم ${piece.pieceId}`}
                                    className={`h-full flex items-center justify-center text-[10px] font-bold transition-all relative group cursor-help ${piece.isPartial ? 'bg-indigo-400 text-indigo-900' : 'bg-slate-600 text-white'}`}
                                    style={{ width: `${(piece.length / state.standardStickLength) * 100}%`, borderRadius: '4px' }}
                                  >
                                    {piece.length}
                                    {piece.isPartial && (
                                      <span className="absolute -top-8 bg-slate-800 text-white text-[8px] px-2 py-1 rounded opacity-0 group-hover:opacity-100 whitespace-nowrap z-10 pointer-events-none transition-opacity">
                                        وصلة لقطعة {piece.pieceId}
                                      </span>
                                    )}
                                  </div>
                                ))}
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}

                    {/* Inner Sticks */}
                    {state.doubleFrame && calculations.innerSticks && calculations.innerSticks.length > 0 && (
                      <div className="space-y-4">
                        <h3 className="text-[10px] font-bold text-indigo-400 uppercase tracking-widest">أعواد البرواز الداخلي</h3>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          {calculations.innerSticks.map((stick, idx) => (
                            <div key={idx} className="bg-indigo-50/50 border border-indigo-100 rounded-2xl p-4 space-y-4">
                              <div className="flex justify-between items-center">
                                <span className="text-xs font-bold text-indigo-600">العود {idx + 1}</span>
                                <span className="text-[10px] font-bold text-indigo-400">المتبقي: {stick.remaining.toFixed(1)} سم</span>
                              </div>
                              <div className="h-8 bg-white rounded-xl flex overflow-hidden border border-indigo-100 p-1 gap-0.5">
                                {stick.pieces.map((piece, pIdx) => (
                                  <div 
                                    key={pIdx}
                                    title={piece.isPartial ? `جزء من قطعة رقم ${piece.pieceId} (إجمالي ${piece.originalLength} سم)` : `قطعة رقم ${piece.pieceId}`}
                                    className={`h-full flex items-center justify-center text-[10px] font-bold transition-all relative group cursor-help ${piece.isPartial ? 'bg-indigo-400 text-indigo-900' : 'bg-indigo-500 text-white'}`}
                                    style={{ width: `${(piece.length / state.standardStickLength) * 100}%`, borderRadius: '4px' }}
                                  >
                                    {piece.length}
                                    {piece.isPartial && (
                                      <span className="absolute -top-8 bg-slate-800 text-white text-[8px] px-2 py-1 rounded opacity-0 group-hover:opacity-100 whitespace-nowrap z-10 pointer-events-none transition-opacity">
                                        وصلة لقطعة {piece.pieceId}
                                      </span>
                                    )}
                                  </div>
                                ))}
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                )}
              </div>
            )}
          </div>
        </div>
      </main>
      <AIAssistant 
        context={{ ...state, ...calculations }} 
        onUpdateState={updateState}
      />
    </div>
  );
}

export default App;
