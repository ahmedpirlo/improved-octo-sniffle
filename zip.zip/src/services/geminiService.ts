import { GoogleGenAI, ThinkingLevel, Type, FunctionDeclaration } from "@google/genai";

let aiInstance: GoogleGenAI | null = null;

function getAI() {
  if (!aiInstance) {
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      throw new Error("GEMINI_API_KEY is missing. Please configure it in the Secrets panel.");
    }
    aiInstance = new GoogleGenAI({ apiKey });
  }
  return aiInstance;
}

const updatePanelConfigDeclaration: FunctionDeclaration = {
  name: "updatePanelConfig",
  description: "Update the panel configuration parameters like dimensions, counts, gaps, and colors.",
  parameters: {
    type: Type.OBJECT,
    properties: {
      wallWidth: { type: Type.NUMBER, description: "Width of the wall in cm" },
      wallHeight: { type: Type.NUMBER, description: "Height of the wall in cm" },
      panelCount: { type: Type.NUMBER, description: "Number of horizontal panels" },
      verticalPanelCount: { type: Type.NUMBER, description: "Number of vertical rows of panels" },
      gap: { type: Type.NUMBER, description: "Gap between panels in cm" },
      margin: { type: Type.NUMBER, description: "Margin from wall edges in cm" },
      swapVertical: { type: Type.BOOLEAN, description: "Swap the vertical distribution (larger panel top/bottom)" },
      doubleFrame: { type: Type.BOOLEAN, description: "Enable double frame (inner frame)" },
      innerGap: { type: Type.NUMBER, description: "Gap for the inner frame in cm" },
      moldingWidth: { type: Type.NUMBER, description: "Width of the molding/frame material in cm" },
      wallColor: { type: Type.STRING, description: "Hex color for the wall" },
      panelColor: { type: Type.STRING, description: "Hex color for the panels" },
      pricePerMeter: { type: Type.NUMBER, description: "Price per linear meter of material" },
    }
  }
};

export async function askAI(prompt: string, context: any) {
  try {
    const ai = getAI();
    const response = await ai.models.generateContent({
      model: "gemini-3.1-flash-lite-preview",
      contents: `
        User Question: ${prompt}
        
        Current App State:
        - Wall Dimensions: ${context.wallWidth}x${context.wallHeight} cm
        - Panel Count: ${context.panelCount}
        - Vertical Rows: ${context.verticalPanelCount}
        - Margin: ${context.margin} cm
        - Gap: ${context.gap} cm
        - Double Frame: ${context.doubleFrame ? 'Yes' : 'No'}
        - Inner Gap: ${context.innerGap} cm
        - Molding Width: ${context.moldingWidth} cm
        - Wall Color: ${context.wallColor}
        - Panel Color: ${context.panelColor}
        
        Calculated Results:
        - Total Meters: ${context.totalLinearMeters.toFixed(2)} m
        - Total Sticks: ${context.totalSticksNeeded}
        - Panel Size: ${context.panelWidth.toFixed(1)}x${context.panelHeight.toFixed(1)} cm
      `,
      config: {
        systemInstruction: `أنت خبير في التصميم الداخلي وتركيب البانوهات. 
        مهمتك هي مساعدة المستخدم في تعديلات بسيطة ومحددة على التصميم الحالي.
        
        قاعدة ذهبية: الهيكل الحالي للتطبيق ثابت ولا يتغير. التعديلات تكون "واحدة واحدة" وبسيطة جداً.
        
        تحدث باللغة العربية بلهجة مصرية بسيطة. 
        لديك القدرة على التحكم في إعدادات التطبيق مباشرة باستخدام أداة updatePanelConfig.
        نفذ التعديلات المطلوبة بدقة وهدوء دون تغيير أي شيء لم يطلبه المستخدم.
        أجب باختصار شديد ووضوح.`,
        tools: [{ functionDeclarations: [updatePanelConfigDeclaration] }],
      }
    });

    return {
      text: response.text,
      functionCalls: response.functionCalls
    };
  } catch (error) {
    console.error("Gemini API Error:", error);
    return {
      text: "عذراً، حدث خطأ أثناء الاتصال بالذكاء الاصطناعي. حاول مرة أخرى.",
      functionCalls: null
    };
  }
}
